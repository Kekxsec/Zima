import{g as o}from"../chunks/auth-Bh-mtPCB.js";import{Z as r,G as i}from"../chunks/overlay-61289_aI.js";import"../chunks/api-Be-UWFOG.js";async function a(){await o()&&chrome.runtime.onMessage.addListener(t=>{t.type==="SHOW_GUIDE"&&t.provider==="proton"&&r.mount(i.proton)})}a();
//# sourceMappingURL=proton.js.map
