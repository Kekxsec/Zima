import{g as o}from"../chunks/auth-Bh-mtPCB.js";import{Z as a,G as i}from"../chunks/overlay-61289_aI.js";import"../chunks/api-Be-UWFOG.js";async function r(){await o()&&chrome.runtime.onMessage.addListener(t=>{t.type==="SHOW_GUIDE"&&t.provider==="yahoo"&&a.mount(i.yahoo)})}r();
//# sourceMappingURL=yahoo.js.map
