import{g as o}from"../chunks/auth-Bh-mtPCB.js";import{Z as e,G as i}from"../chunks/overlay-61289_aI.js";import"../chunks/api-Be-UWFOG.js";const r="zima_outlook_guide_triggered";async function a(){await o()&&chrome.runtime.onMessage.addListener(t=>{t.type==="SHOW_GUIDE"&&t.provider==="outlook"&&(sessionStorage.setItem(r,"1"),e.mount(i.outlook))})}a();
//# sourceMappingURL=outlook.js.map
