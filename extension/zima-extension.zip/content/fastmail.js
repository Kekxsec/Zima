import{g as a}from"../chunks/auth-Bh-mtPCB.js";import{Z as i,G as r}from"../chunks/overlay-61289_aI.js";import"../chunks/api-Be-UWFOG.js";async function e(){await a()&&chrome.runtime.onMessage.addListener(t=>{t.type==="SHOW_GUIDE"&&t.provider==="fastmail"&&i.mount(r.fastmail)})}e();
//# sourceMappingURL=fastmail.js.map
